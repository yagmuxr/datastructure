struct node{
	int data;
	node* link;
};
node* list=NULL;
node* l1=NULL;
node* l2=NULL;
void dumplist()
{
int count=0;
{
	while(list->link!=NULL)
	cout<<i<<". eleman�n"<<endl; 
	       <<"adresi:"<<list;
	       <<"datas�:"<<list->data;
	       <<"linki:"<<list->link;
	       <<endl;
	       i++;
	       list=list->link;
    dumplist();	       
}
}
