//parametre olarak gelen 10 elemanl� integer dizideki verileri ayn� dizi �zerinde indis numaras�na g�re tersten yerle�tirerek geri g�nderen tersyerlestir()
#include<iostream>
#include<stdlib.h> 
#include<time.h>
#include<locale.h> 
#include <iomanip> 
#include <conio.h> 
using namespace std; 
#define KAPASITE 10
int main()
{
  void dizisiralaters(int* veri);
  void diziyaz(int*);
  int veri[KAPASITE];
  int i,j;
  int yedek=0;
  int sayi;
  
  srand(time(NULL));
  
  //diziyi 1-100 aras�nda rastgele say�lar ile doldur
  for(i=0; i< KAPASITE ; i++)
  {
  	sayi=rand() % 100 +1;
  	veri[i] = sayi;
  }
   diziyaz(veri);
   dizisiralaters(veri);
   diziyaz(veri);
   system("PAUSE");
   return 0;
}
void diziyaz(int* veri)
{
	cout<<"------------------------}\n";
	//diziyi yazd�r
	for(int i=0 ; i < KAPASITE ; i++ )
	{
		cout << *veri++ << endl;
	}
}
void dizisiralaters(int* veri)
{
	int yedek;
	//pointer ile de�il :(
	for(int i=0 ; i<(KAPASITE/2) ; i++)
	{
		yedek=veri[i];
		veri[i]=veri[KAPASITE-1];
		veri[KAPASITE-1-i]=yedek;
	}
}

