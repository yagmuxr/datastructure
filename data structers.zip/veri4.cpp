//iki adet bir ba�l� do�rusal liste birbirinin kopyas� ise geriye true, de�ilse geriye false g�nderen karsilastir()
#include<iostream>
#include<stdlib.h> 
#include<time.h>
#include<locale.h> 
#include <iomanip> 
#include <conio.h> 
#include "bbdol.h"
using namespace std;
bool karsilastir(node*& l1, node* l2)
{
	bool karsilastir=false;
	if(l1==NULL && l2==NULL)
	{
		karsilastir=true;
		return(karsilastir);
	}
	while(l1!=NULL && l2!=NULL)
	{
		l1=l1->link;
		l2=l2->link;
		karsilastir=true;
	}
	return(karsilastir);
}
int main()
{
	node* list1;
	node* list2;
	addhead(newnode(),list1);
	addhead(newnode(),list1);
	addhead(newnode(),list1);
	addhead(newnode(),list2);
	addhead(newnode(),list2);
	addhead(newnode(),list2);
	karsilastir(list1, list2);
}
