struct node{
	int data;
	node* link;
};
node* list=NULL;
node* l1=NULL;
node* l2=NULL;

node* last(node* link){
	while(list->link!=NULL){
	list=list->link;
	last(link);
   }
   node* last=list;
   return(last);
}
