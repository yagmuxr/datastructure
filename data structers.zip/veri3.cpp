//iki ba�l� dairesel listeyi iki ba�l� do�rusal listeye d�n��t�ren ve �a�r�ld��� yere geriye g�nderen donu�tur()
#include<iostream>
#include<stdlib.h> 
#include<time.h>
#include<locale.h> 
#include <iomanip> 
#include <conio.h> 
using namespace std;
struct node{
	int data;
	node* blink;
	node* flink;
};
node* newnode()
{
	node* newnode=new node;
	newnode->blink=newnode;
	newnode->flink=newnode;
	return(newnode);
}
node* last(node* l1)
{
    node* last=NULL;
	if(l1!=NULL)last=l1->blink;
	return(last);
}
void addhead(node* node_, node*& l1)
{
	if(l1!=NULL)
	{
		node_->flink=l1;
		l1->blink=node_;
	}
	l1=node_;
}

node donustur(node*& l1)
{
	node* last=NULL;
	if(l1!=NULL)last=l1->blink;
	last->flink=NULL;
	l1->blink=NULL;
}
int main()
{
	node* list1=NULL;
	addhead(newnode(),list1);
	addhead(newnode(),list1);
	addhead(newnode(),list1);
	addhead(newnode(),list1);
	donustur(list1);
	
}

