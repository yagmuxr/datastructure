//bir ba�l� do�rusal listedeki datalar�n ortalamas�n� bulan ortalama() ad�nda recursive
#include<iostream>
#include<stdlib.h> 
#include<time.h>
#include<locale.h> 
#include <iomanip> 
#include <conio.h> 
using namespace std;
struct node{
	int data;
	node* link;
};
float ortalama(node* list)
{
	node* ydk=list;
	int total=0;
	float avg;
	if(list==NULL) return total;
	do
	{
		i++;
		total=list->data + ortalama(list->link);
	}while(list!=ydk);
	avg=ortalama/i;
	return(avg);
}
int main()
{
	node* l1;
	addhead(cons(40),l1);
	addhead(cons(30),l1);
	addhead(cons(20),l1);
	addhead(cons(10),l1);
	dumplist(l1);
	
	cout<<ortalama(l1);
	getch();
	return 0;
}
