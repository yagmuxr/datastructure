//bir ba�l� dairesel listedeki nodelar�n datalar�n�n ortalamas�n� hesaplay�p geriye g�nderen ortalamaal()
#include<iostream>
#include<stdlib.h> 
#include<time.h>
#include<locale.h> 
#include <iomanip> 
#include <conio.h> 
using namespace std;
struct node{
	int data;
	node* link;
};
void dumplist(node* list)
{
	int i=1;
	node* ylist=list;

	do
	{
		cout << "Listenin " << i << ". Node'unun Adresi = " << list << " Datasi = " << list->data << " Linki = " << list->link << endl;
		list = list->link;
		i++;
	}while(list=ylist);
}
node* newnode()
{
	node* newnode = new node;
	newnode->link = newnode;
	return(newnode);
}
void addhead(node* node_, node*& list)
{
	node_->link = list;
	list = node_;
}
node* cons(int data_)
{
	node* cons_;
	cons_=newnode();
	cons_->data=data_;
	return(cons_);
}
float ortalamaal(node* list){
	int toplam=0, i=0;
	float ortalama;
	node* ydk=list;
	while(list->link!=ydk)
	{
	 i++;
	 toplam+=list->data;
	}
	ortalama=toplam/i;
	cout<<"Datalar�n ortalamas�: "<<ortalama;
	return(ortalama);
}
int main()
{
	node* list1;
	addhead(cons(40),list1);
	addhead(cons(30),list1);
	addhead(cons(20),list1);
	addhead(cons(10),list1);
	dumplist(list1);
	ortalamaal(list1);
}
