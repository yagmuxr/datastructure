// integer bir datan�n yine kendisine parametre olarak gelen bit s�ras�ndaki biti 1 ise geriye true, 0 ise false d�nd�ren bitkontrol()

#include<iostream>
#include<stdlib.h> 
#include<time.h>
#include<locale.h> 
#include <iomanip> 
#include <conio.h> 
using namespace std; 
bool bitkontrol(int data, int a)
{
  bool kontrol;
  if((data & 1<<a) != 0){
  	kontrol=true;
  	cout<<"Say�n�n "<<a<<". biti 1'dir."<<endl;
  }
  else
  {
  kontrol=false;
  cout<<"Say�n�n "<<a<<". biti 0'd�r."<<endl;
}
}
int main()
{
	setlocale(LC_ALL,"Turkish");
	int data1, b;
  cout<<"Say�y� giriniz: ";
  cin>>data1;
  cout<<"Ka��nc� bit giriniz: ";
  cin>>b;
  bitkontrol(data1,b);
}
